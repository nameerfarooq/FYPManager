import React from 'react'
// eslint-disable-next-line
import CreateProject from '../Project/CreateProject'
// eslint-disable-next-line
import MainProjectScreen from '../Project/MainProjectScreen'
import ViewProject from '../Project/ViewProject'
import './style.css'
function DashboardMain() {
    return (
        <div className='DashboardMain'>
            
           {/* Main Screen for projects (view and create new)  */}
            {/* <MainProjectScreen /> */}
            
            {/* create project screen */}
            {/* <CreateProject/> */}
            
            {/* view project screen */}
            <ViewProject/>
            
            
        </div>
    )
}

export default DashboardMain